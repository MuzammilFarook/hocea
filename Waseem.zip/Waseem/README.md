# CampusHub — Campus Services Management Portal

> Built for TechSymposium 2025 Hackathon

A full-stack campus services platform with a student portal, event announcements, facility booking, and a live notice board.

---

## Tech Stack

| Layer       | Technology                          |
|-------------|-------------------------------------|
| Frontend    | React 18 + Vite                     |
| Backend     | Node.js + Express.js                |
| Database    | MongoDB + Mongoose                  |
| Auth        | JWT + bcryptjs                      |
| Real-time   | Socket.io                           |
| HTTP Client | Axios                               |
| Routing     | React Router v6                     |

---

## Project Structure

```
campushub/
├── campushub-server/       ← Express API
│   ├── config/db.js
│   ├── middleware/auth.js
│   ├── models/             (Student, Event, Facility, Notice)
│   ├── routes/             (auth, students, events, facilities, notices)
│   ├── seed.js
│   ├── index.js
│   └── .env.example
│
└── campushub-client/       ← React + Vite
    └── src/
        ├── context/        (AuthContext)
        ├── hooks/          (useSocket)
        ├── services/       (axios instance)
        ├── components/     (Sidebar, AppLayout, Badge)
        └── pages/          (Login, Register, Portal, Events, Facilities, Notices)
```

---

## Quick Start

### 1. Prerequisites
- Node.js 18+
- MongoDB running locally (`mongod`) or a MongoDB Atlas URI

### 2. Backend

```bash
cd campushub-server
cp .env.example .env          # edit MONGO_URI if using Atlas
npm install
node seed.js                  # loads demo data
npm run dev                   # API on http://localhost:5000
```

### 3. Frontend

```bash
cd campushub-client
npm install
npm run dev                   # UI on http://localhost:3000
```

---

## Demo Credentials

| Role    | Email                | Password    |
|---------|----------------------|-------------|
| Student | arjun@campus.edu     | password123 |
| Admin   | admin@campus.edu     | admin123    |

---

## Features

### Student Portal
- CGPA, attendance, and credit metrics at a glance
- Enrolled courses with per-course attendance progress bars
- Attendance warning if below 75%
- Personalised notice feed (filtered by year + department)

### Event Announcements
- Upcoming events with date cards
- Category filter (academic, cultural, sports, placement, workshop)
- One-click RSVP with live seat count
- Cancel RSVP support
- Capacity enforcement (full events auto-disable RSVP)

### Campus Facilities
- Live occupancy bar per facility (colour-coded: green → amber → red)
- Real-time updates via Socket.io — no refresh needed
- Date-picker + slot grid for time-slot booking
- Cancel booking support
- Facilities: CS Lab, Library, Sports Complex, Cafeteria, Seminar Hall, Health Center

### Notice Board
- Priority filter (Urgent / Normal / Info)
- Left-border colour coding by priority
- Targeted by year and department server-side

---

## API Endpoints Summary

```
POST   /api/auth/register
POST   /api/auth/login

GET    /api/students/me
GET    /api/students/me/courses

GET    /api/events?upcoming=true
POST   /api/events/:id/rsvp
DELETE /api/events/:id/rsvp

GET    /api/facilities
GET    /api/facilities/:id/slots?date=YYYY-MM-DD
POST   /api/facilities/:id/book
DELETE /api/facilities/:id/book/:bookingId

GET    /api/notices
```

---

## Real-time (Socket.io)

The frontend listens on the `facility:updated` event. Every booking or cancellation emits:

```json
{
  "facilityId": "...",
  "status": "available | busy | closed",
  "currentOccupancy": 12,
  "availableCapacity": 28
}
```

---

## Hackathon Presentation Tips

1. **Start the demo on the Login page** — shows the clean navy split-panel design immediately
2. **RSVP to an event** — instant UI feedback, no reload
3. **Open Facilities → book a slot** — the slot grid auto-generates from open/close times
4. **Open two browser tabs** — book a slot in one, watch the occupancy bar update in the other (Socket.io live demo)
5. **Show the Notice Board** — highlight the department/year filtering as a backend feature

---

*Good luck at TechSymposium 2025!*
