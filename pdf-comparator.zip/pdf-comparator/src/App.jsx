import React, { useState, useCallback, useRef, useEffect } from 'react';
import * as pdfjsLib from 'pdfjs-dist';
import pixelmatch from 'pixelmatch';

// Set up PDF.js worker - use the matching version from the package
pdfjsLib.GlobalWorkerOptions.workerSrc = new URL(
  'pdfjs-dist/build/pdf.worker.min.mjs',
  import.meta.url
).toString();

/**
 * Extract text content from a PDF page
 */
async function extractPageText(pdfDoc, pageNum) {
  const page = await pdfDoc.getPage(pageNum);
  const textContent = await page.getTextContent();
  
  // Group text items by their vertical position (y coordinate) to preserve lines
  const lineMap = new Map();
  
  textContent.items.forEach(item => {
    const y = Math.round(item.transform[5]); // Round y position to group nearby items
    if (!lineMap.has(y)) {
      lineMap.set(y, []);
    }
    lineMap.get(y).push(item.str);
  });
  
  // Sort by y position (descending, since PDF y-axis goes up) and join
  const sortedLines = Array.from(lineMap.entries())
    .sort((a, b) => b[0] - a[0])
    .map(([_, texts]) => texts.join(' ').trim())
    .filter(line => line.length > 0);
  
  return sortedLines;
}

/**
 * Simple diff function to find added, removed, and changed lines
 */
function diffLines(originalLines, revisedLines) {
  const changes = {
    added: [],
    removed: [],
    modified: []
  };
  
  const originalSet = new Set(originalLines);
  const revisedSet = new Set(revisedLines);
  
  // Find removed lines (in original but not in revised)
  originalLines.forEach(line => {
    if (!revisedSet.has(line)) {
      // Check if it's modified (similar line exists)
      const similar = revisedLines.find(rLine => 
        similarity(line, rLine) > 0.6 && !originalSet.has(rLine)
      );
      if (similar) {
        changes.modified.push({ original: line, revised: similar });
        revisedSet.delete(similar); // Mark as used
      } else {
        changes.removed.push(line);
      }
    }
  });
  
  // Find added lines (in revised but not in original, and not already matched as modified)
  revisedLines.forEach(line => {
    if (!originalSet.has(line) && !changes.modified.some(m => m.revised === line)) {
      changes.added.push(line);
    }
  });
  
  return changes;
}

/**
 * Calculate similarity between two strings (0-1)
 */
function similarity(str1, str2) {
  const longer = str1.length > str2.length ? str1 : str2;
  const shorter = str1.length > str2.length ? str2 : str1;
  
  if (longer.length === 0) return 1.0;
  
  const costs = [];
  for (let i = 0; i <= shorter.length; i++) {
    let lastValue = i;
    for (let j = 0; j <= longer.length; j++) {
      if (i === 0) {
        costs[j] = j;
      } else if (j > 0) {
        let newValue = costs[j - 1];
        if (shorter.charAt(i - 1) !== longer.charAt(j - 1)) {
          newValue = Math.min(Math.min(newValue, lastValue), costs[j]) + 1;
        }
        costs[j - 1] = lastValue;
        lastValue = newValue;
      }
    }
    if (i > 0) costs[longer.length] = lastValue;
  }
  
  return (longer.length - costs[longer.length]) / longer.length;
}

/**
 * Analyze diff array to find change regions and categorize them
 */
function analyzeChanges(diffArray, width, height, originalText, revisedText) {
  const analysis = {
    textChanges: {
      added: [],
      removed: [],
      modified: []
    },
    layoutChanges: {
      detected: false,
      regions: []
    },
    visualChanges: {
      detected: false,
      description: []
    },
    statistics: {
      totalPixelsChanged: 0,
      percentageChanged: 0,
      changeRegions: 0
    }
  };
  
  // 1. Text changes (existing logic)
  const originalSet = new Set(originalText);
  const revisedSet = new Set(revisedText);
  const matchedRevised = new Set();
  
  originalText.forEach(line => {
    if (!revisedSet.has(line)) {
      const similar = revisedText.find(rLine => 
        similarity(line, rLine) > 0.6 && !originalSet.has(rLine) && !matchedRevised.has(rLine)
      );
      if (similar) {
        analysis.textChanges.modified.push({ original: line, revised: similar });
        matchedRevised.add(similar);
      } else if (line.trim().length > 0) {
        analysis.textChanges.removed.push(line);
      }
    }
  });
  
  revisedText.forEach(line => {
    if (!originalSet.has(line) && !matchedRevised.has(line) && line.trim().length > 0) {
      analysis.textChanges.added.push(line);
    }
  });
  
  // 2. Analyze pixel diff for regions
  let changedPixels = 0;
  const changeMap = []; // Grid to track where changes occur
  const gridSize = 50; // Analyze in 50x50 pixel blocks
  const gridWidth = Math.ceil(width / gridSize);
  const gridHeight = Math.ceil(height / gridSize);
  
  // Initialize grid
  for (let gy = 0; gy < gridHeight; gy++) {
    changeMap[gy] = [];
    for (let gx = 0; gx < gridWidth; gx++) {
      changeMap[gy][gx] = 0;
    }
  }
  
  // Count changed pixels and map to grid
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const idx = (y * width + x) * 4;
      if (diffArray[idx] > 10 || diffArray[idx + 1] > 10 || diffArray[idx + 2] > 10) {
        changedPixels++;
        const gx = Math.floor(x / gridSize);
        const gy = Math.floor(y / gridSize);
        if (changeMap[gy] && changeMap[gy][gx] !== undefined) {
          changeMap[gy][gx]++;
        }
      }
    }
  }
  
  analysis.statistics.totalPixelsChanged = changedPixels;
  analysis.statistics.percentageChanged = ((changedPixels / (width * height)) * 100).toFixed(2);
  
  // 3. Identify change regions (top, middle, bottom, left, right)
  const regions = {
    header: 0,    // Top 15%
    body: 0,      // Middle 70%
    footer: 0,    // Bottom 15%
    leftMargin: 0,
    rightMargin: 0
  };
  
  const headerLimit = Math.floor(gridHeight * 0.15);
  const footerStart = Math.floor(gridHeight * 0.85);
  const marginWidth = Math.floor(gridWidth * 0.1);
  
  for (let gy = 0; gy < gridHeight; gy++) {
    for (let gx = 0; gx < gridWidth; gx++) {
      const changes = changeMap[gy][gx];
      if (changes > 100) { // Significant change threshold
        analysis.statistics.changeRegions++;
        
        if (gy < headerLimit) regions.header += changes;
        else if (gy >= footerStart) regions.footer += changes;
        else regions.body += changes;
        
        if (gx < marginWidth) regions.leftMargin += changes;
        else if (gx >= gridWidth - marginWidth) regions.rightMargin += changes;
      }
    }
  }
  
  // 4. Generate layout change descriptions
  if (regions.header > 1000) {
    analysis.layoutChanges.detected = true;
    analysis.layoutChanges.regions.push('Header area modified');
  }
  if (regions.footer > 1000) {
    analysis.layoutChanges.detected = true;
    analysis.layoutChanges.regions.push('Footer area modified');
  }
  if (regions.leftMargin > 500 || regions.rightMargin > 500) {
    analysis.layoutChanges.detected = true;
    analysis.layoutChanges.regions.push('Margin/spacing changes detected');
  }
  
  // 5. Detect visual/image changes (large contiguous change blocks)
  for (let gy = 0; gy < gridHeight; gy++) {
    for (let gx = 0; gx < gridWidth; gx++) {
      const changes = changeMap[gy][gx];
      const blockPixels = gridSize * gridSize;
      if (changes > blockPixels * 0.5) { // More than 50% of block changed
        analysis.visualChanges.detected = true;
        const yPercent = Math.round((gy / gridHeight) * 100);
        const xPercent = Math.round((gx / gridWidth) * 100);
        const position = yPercent < 20 ? 'top' : yPercent > 80 ? 'bottom' : 'middle';
        const hPosition = xPercent < 30 ? 'left' : xPercent > 70 ? 'right' : 'center';
        analysis.visualChanges.description.push(`Visual change at ${position}-${hPosition}`);
      }
    }
  }
  
  // Deduplicate visual descriptions
  analysis.visualChanges.description = [...new Set(analysis.visualChanges.description)];
  
  return analysis;
}

// Icons as simple SVG components
const UploadIcon = () => (
  <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
    <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M17 8l-5-5-5 5M12 3v12"/>
  </svg>
);

const CheckIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
    <polyline points="20,6 9,17 4,12"/>
  </svg>
);

const SpinnerIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="spinner">
    <path d="M21 12a9 9 0 11-6.219-8.56"/>
  </svg>
);

/**
 * Slider comparison component - drag to reveal
 */
function SliderCompare({ originalImage, revisedImage }) {
  const [sliderPos, setSliderPos] = useState(50);
  const containerRef = useRef(null);
  const isDragging = useRef(false);

  const handleMove = useCallback((clientX) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    const percent = Math.max(0, Math.min(100, (x / rect.width) * 100));
    setSliderPos(percent);
  }, []);

  const handleMouseDown = () => { isDragging.current = true; };
  const handleMouseUp = () => { isDragging.current = false; };
  const handleMouseMove = (e) => { if (isDragging.current) handleMove(e.clientX); };
  const handleTouchMove = (e) => { handleMove(e.touches[0].clientX); };

  useEffect(() => {
    document.addEventListener('mouseup', handleMouseUp);
    document.addEventListener('mousemove', handleMouseMove);
    return () => {
      document.removeEventListener('mouseup', handleMouseUp);
      document.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  return (
    <div className="slider-compare-container">
      <h4>Drag slider to compare</h4>
      <div 
        className="slider-compare" 
        ref={containerRef}
        onTouchMove={handleTouchMove}
      >
        <div className="slider-image-container">
          <img src={revisedImage} alt="Revised" className="slider-image" />
        </div>
        <div 
          className="slider-image-container slider-clip" 
          style={{ clipPath: `inset(0 ${100 - sliderPos}% 0 0)` }}
        >
          <img src={originalImage} alt="Original" className="slider-image" />
        </div>
        <div 
          className="slider-handle"
          style={{ left: `${sliderPos}%` }}
          onMouseDown={handleMouseDown}
          onTouchStart={handleMouseDown}
        >
          <div className="slider-line"></div>
          <div className="slider-grip">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
              <path d="M8 5l-5 7 5 7V5zm8 0v14l5-7-5-7z"/>
            </svg>
          </div>
        </div>
        <div className="slider-label left">Original</div>
        <div className="slider-label right">Revised</div>
      </div>
    </div>
  );
}

/**
 * Toggle/Flicker comparison component
 */
function ToggleCompare({ originalImage, revisedImage }) {
  const [showOriginal, setShowOriginal] = useState(true);
  const [autoFlicker, setAutoFlicker] = useState(false);

  useEffect(() => {
    if (!autoFlicker) return;
    const interval = setInterval(() => {
      setShowOriginal(prev => !prev);
    }, 500);
    return () => clearInterval(interval);
  }, [autoFlicker]);

  return (
    <div className="toggle-compare-container">
      <div className="toggle-controls">
        <button 
          className={`toggle-btn ${showOriginal ? 'active' : ''}`}
          onClick={() => { setAutoFlicker(false); setShowOriginal(true); }}
        >
          Original
        </button>
        <button 
          className={`toggle-btn ${!showOriginal ? 'active' : ''}`}
          onClick={() => { setAutoFlicker(false); setShowOriginal(false); }}
        >
          Revised
        </button>
        <button 
          className={`toggle-btn flicker ${autoFlicker ? 'active' : ''}`}
          onClick={() => setAutoFlicker(!autoFlicker)}
        >
          {autoFlicker ? '⏹ Stop' : '⚡ Flicker'}
        </button>
      </div>
      <div className="toggle-image-container">
        <img 
          src={showOriginal ? originalImage : revisedImage} 
          alt={showOriginal ? "Original" : "Revised"} 
        />
        <div className="toggle-label">{showOriginal ? 'ORIGINAL' : 'REVISED'}</div>
      </div>
    </div>
  );
}

/**
 * Comprehensive Change Summary component
 */
function ChangeSummary({ analysis, status }) {
  const [expandedSections, setExpandedSections] = useState({
    text: true,
    layout: true,
    visual: true
  });
  
  if (!analysis) return null;
  
  const toggleSection = (section) => {
    setExpandedSections(prev => ({ ...prev, [section]: !prev[section] }));
  };
  
  const { textChanges, layoutChanges, visualChanges, statistics } = analysis;
  const hasTextChanges = textChanges.added.length > 0 || textChanges.removed.length > 0 || textChanges.modified.length > 0;
  
  return (
    <div className="change-summary">
      {/* Statistics Bar */}
      <div className="stats-bar">
        <div className="stat-item">
          <span className="stat-value">{statistics.percentageChanged}%</span>
          <span className="stat-label">Changed</span>
        </div>
        <div className="stat-item">
          <span className="stat-value">{statistics.totalPixelsChanged.toLocaleString()}</span>
          <span className="stat-label">Pixels</span>
        </div>
        <div className="stat-item">
          <span className="stat-value">{statistics.changeRegions}</span>
          <span className="stat-label">Regions</span>
        </div>
      </div>
      
      {/* 1. Text Changes */}
      <div className="summary-section">
        <div className="section-header" onClick={() => toggleSection('text')}>
          <h4>📝 Text Changes</h4>
          <span className="section-badge">
            {textChanges.modified.length + textChanges.added.length + textChanges.removed.length} changes
          </span>
          <span className="expand-icon">{expandedSections.text ? '▼' : '▶'}</span>
        </div>
        
        {expandedSections.text && (
          <div className="section-content">
            {!hasTextChanges ? (
              <p className="no-changes">No text content changes detected</p>
            ) : (
              <>
                {textChanges.modified.length > 0 && (
                  <div className="change-group modified">
                    <h5>🟡 Modified Text ({textChanges.modified.length})</h5>
                    <ul>
                      {textChanges.modified.slice(0, 8).map((change, idx) => (
                        <li key={idx} className="modified-item">
                          <span className="from">{change.original}</span>
                          <span className="arrow">→</span>
                          <span className="to">{change.revised}</span>
                        </li>
                      ))}
                      {textChanges.modified.length > 8 && (
                        <li className="more-items">+{textChanges.modified.length - 8} more changes</li>
                      )}
                    </ul>
                  </div>
                )}
                
                {textChanges.added.length > 0 && (
                  <div className="change-group added">
                    <h5>🟢 Added Text ({textChanges.added.length})</h5>
                    <ul>
                      {textChanges.added.slice(0, 6).map((line, idx) => (
                        <li key={idx}>{line}</li>
                      ))}
                      {textChanges.added.length > 6 && (
                        <li className="more-items">+{textChanges.added.length - 6} more lines</li>
                      )}
                    </ul>
                  </div>
                )}
                
                {textChanges.removed.length > 0 && (
                  <div className="change-group removed">
                    <h5>🔴 Removed Text ({textChanges.removed.length})</h5>
                    <ul>
                      {textChanges.removed.slice(0, 6).map((line, idx) => (
                        <li key={idx}>{line}</li>
                      ))}
                      {textChanges.removed.length > 6 && (
                        <li className="more-items">+{textChanges.removed.length - 6} more lines</li>
                      )}
                    </ul>
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </div>
      
      {/* 2. Layout Changes */}
      <div className="summary-section">
        <div className="section-header" onClick={() => toggleSection('layout')}>
          <h4>📐 Layout & Spacing</h4>
          <span className={`section-badge ${layoutChanges.detected ? 'has-changes' : ''}`}>
            {layoutChanges.detected ? layoutChanges.regions.length + ' detected' : 'No changes'}
          </span>
          <span className="expand-icon">{expandedSections.layout ? '▼' : '▶'}</span>
        </div>
        
        {expandedSections.layout && (
          <div className="section-content">
            {!layoutChanges.detected ? (
              <p className="no-changes">No layout or spacing changes detected</p>
            ) : (
              <ul className="layout-list">
                {layoutChanges.regions.map((region, idx) => (
                  <li key={idx}>
                    <span className="layout-icon">↔️</span>
                    {region}
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}
      </div>
      
      {/* 3. Visual Changes */}
      <div className="summary-section">
        <div className="section-header" onClick={() => toggleSection('visual')}>
          <h4>🖼️ Visual & Image Changes</h4>
          <span className={`section-badge ${visualChanges.detected ? 'has-changes' : ''}`}>
            {visualChanges.detected ? visualChanges.description.length + ' areas' : 'No changes'}
          </span>
          <span className="expand-icon">{expandedSections.visual ? '▼' : '▶'}</span>
        </div>
        
        {expandedSections.visual && (
          <div className="section-content">
            {!visualChanges.detected ? (
              <p className="no-changes">No significant visual or image changes detected</p>
            ) : (
              <ul className="visual-list">
                {visualChanges.description.map((desc, idx) => (
                  <li key={idx}>
                    <span className="visual-icon">🔲</span>
                    {desc}
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

/**
 * Render a PDF page to a canvas and return image data
 */
async function renderPdfPage(pdfDoc, pageNum, scale = 1.5) {
  const page = await pdfDoc.getPage(pageNum);
  const viewport = page.getViewport({ scale });
  
  // Ensure integer dimensions
  const width = Math.ceil(viewport.width);
  const height = Math.ceil(viewport.height);
  
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  
  const context = canvas.getContext('2d');
  context.fillStyle = 'white';
  context.fillRect(0, 0, width, height);
  
  await page.render({
    canvasContext: context,
    viewport: viewport
  }).promise;
  
  return {
    canvas,
    width,
    height,
    dataUrl: canvas.toDataURL('image/png')
  };
}

/**
 * Compare two PDF documents entirely in the browser
 */
async function comparePdfs(file1, file2, onProgress, options = {}) {
  const { scale = 1.5, threshold = 0.1 } = options;
  
  // Read files as ArrayBuffer
  const [buffer1, buffer2] = await Promise.all([
    file1.arrayBuffer(),
    file2.arrayBuffer()
  ]);
  
  // Load PDF documents
  const [doc1, doc2] = await Promise.all([
    pdfjsLib.getDocument({ data: buffer1 }).promise,
    pdfjsLib.getDocument({ data: buffer2 }).promise
  ]);
  
  const results = {
    originalPages: doc1.numPages,
    revisedPages: doc2.numPages,
    pages: [],
    summary: {
      identical: 0,
      modified: 0,
      added: 0,
      removed: 0,
      totalChangedPixels: 0
    },
    metadata: {
      comparedAt: new Date().toISOString(),
      scale,
      threshold
    }
  };
  
  const maxPages = Math.max(doc1.numPages, doc2.numPages);
  
  for (let i = 1; i <= maxPages; i++) {
    onProgress({ current: i, total: maxPages, status: `Comparing page ${i} of ${maxPages}...` });
    
    const pageResult = {
      pageNumber: i,
      status: 'identical',
      diffPercentage: 0,
      changedPixels: 0
    };
    
    if (i > doc1.numPages) {
      // Page only exists in revised document
      pageResult.status = 'added';
      results.summary.added++;
      
      const render = await renderPdfPage(doc2, i, scale);
      pageResult.revisedImage = render.dataUrl;
      
      // Extract text for added page
      const revisedText = await extractPageText(doc2, i);
      pageResult.textSummary = {
        added: revisedText,
        removed: [],
        modified: []
      };
      
    } else if (i > doc2.numPages) {
      // Page only exists in original document
      pageResult.status = 'removed';
      results.summary.removed++;
      
      const render = await renderPdfPage(doc1, i, scale);
      pageResult.originalImage = render.dataUrl;
      
      // Extract text for removed page
      const originalText = await extractPageText(doc1, i);
      pageResult.textSummary = {
        added: [],
        removed: originalText,
        modified: []
      };
      
    } else {
      // Compare pages visually
      const [render1, render2] = await Promise.all([
        renderPdfPage(doc1, i, scale),
        renderPdfPage(doc2, i, scale)
      ]);
      
      // Use consistent dimensions - take the max and ensure integers
      const width = Math.ceil(Math.max(render1.width, render2.width));
      const height = Math.ceil(Math.max(render1.height, render2.height));
      
      // Create normalized canvas for original
      const canvas1 = document.createElement('canvas');
      canvas1.width = width;
      canvas1.height = height;
      const ctx1 = canvas1.getContext('2d', { willReadFrequently: true });
      ctx1.fillStyle = 'white';
      ctx1.fillRect(0, 0, width, height);
      ctx1.drawImage(render1.canvas, 0, 0, render1.width, render1.height);
      
      // Create normalized canvas for revised
      const canvas2 = document.createElement('canvas');
      canvas2.width = width;
      canvas2.height = height;
      const ctx2 = canvas2.getContext('2d', { willReadFrequently: true });
      ctx2.fillStyle = 'white';
      ctx2.fillRect(0, 0, width, height);
      ctx2.drawImage(render2.canvas, 0, 0, render2.width, render2.height);
      
      // Get image data from the normalized canvases
      const img1Data = ctx1.getImageData(0, 0, width, height);
      const img2Data = ctx2.getImageData(0, 0, width, height);
      
      // Verify sizes match (they should now)
      if (img1Data.data.length !== img2Data.data.length) {
        console.error(`Size mismatch on page ${i}: ${img1Data.data.length} vs ${img2Data.data.length}`);
        pageResult.status = 'modified';
        pageResult.diffPercentage = 100;
        pageResult.originalImage = canvas1.toDataURL('image/png');
        pageResult.revisedImage = canvas2.toDataURL('image/png');
        results.summary.modified++;
        results.pages.push(pageResult);
        continue;
      }
      
      // Create output array for diff (4 bytes per pixel: RGBA)
      const diffArray = new Uint8ClampedArray(width * height * 4);
      
      // Perform pixel comparison
      const diffPixels = pixelmatch(
        img1Data.data,
        img2Data.data,
        diffArray,
        width,
        height,
        { 
          threshold,
          diffColor: [239, 68, 68],      // Red for differences
          diffColorAlt: [59, 130, 246],  // Blue for anti-aliased
          alpha: 0.1
        }
      );
      
      const totalPixels = width * height;
      const diffPercentage = (diffPixels / totalPixels) * 100;
      
      pageResult.diffPercentage = parseFloat(diffPercentage.toFixed(2));
      pageResult.changedPixels = diffPixels;
      
      if (diffPixels > 0) {
        pageResult.status = 'modified';
        results.summary.modified++;
        results.summary.totalChangedPixels += diffPixels;
        
        // Extract text from both pages
        const [originalText, revisedText] = await Promise.all([
          extractPageText(doc1, i),
          extractPageText(doc2, i)
        ]);
        
        // Comprehensive change analysis
        pageResult.changeAnalysis = analyzeChanges(
          diffArray, 
          width, 
          height, 
          originalText, 
          revisedText
        );
        
        // Create highlighted diff - original with subtle red overlay on changed areas
        const highlightCanvas = document.createElement('canvas');
        highlightCanvas.width = width;
        highlightCanvas.height = height;
        const highlightCtx = highlightCanvas.getContext('2d');
        
        // Draw original first
        highlightCtx.drawImage(canvas1, 0, 0);
        
        // Create a red overlay canvas for just the changed pixels
        const redOverlay = document.createElement('canvas');
        redOverlay.width = width;
        redOverlay.height = height;
        const redCtx = redOverlay.getContext('2d');
        const redData = redCtx.createImageData(width, height);
        
        // Mark changed pixels with semi-transparent red
        for (let j = 0; j < diffArray.length; j += 4) {
          // If this pixel is different (check if diff pixel is not black)
          if (diffArray[j] > 10 || diffArray[j + 1] > 10 || diffArray[j + 2] > 10) {
            redData.data[j] = 239;      // R
            redData.data[j + 1] = 68;   // G  
            redData.data[j + 2] = 68;   // B
            redData.data[j + 3] = 120;  // A - semi-transparent
          }
        }
        
        redCtx.putImageData(redData, 0, 0);
        
        // Overlay the red highlights on the original
        highlightCtx.drawImage(redOverlay, 0, 0);
        
        // Create side-by-side blend overlay (for Overlay view mode)
        const overlayCanvas = document.createElement('canvas');
        overlayCanvas.width = width;
        overlayCanvas.height = height;
        const overlayCtx = overlayCanvas.getContext('2d');
        overlayCtx.drawImage(canvas1, 0, 0);
        overlayCtx.globalAlpha = 0.5;
        overlayCtx.drawImage(canvas2, 0, 0);
        
        pageResult.originalImage = canvas1.toDataURL('image/png');
        pageResult.revisedImage = canvas2.toDataURL('image/png');
        pageResult.diffImage = highlightCanvas.toDataURL('image/png');
        pageResult.overlayImage = overlayCanvas.toDataURL('image/png');
      } else {
        results.summary.identical++;
      }
    }
    
    results.pages.push(pageResult);
  }
  
  return results;
}

function App() {
  const [originalFile, setOriginalFile] = useState(null);
  const [revisedFile, setRevisedFile] = useState(null);
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(null);
  const [error, setError] = useState(null);
  const [selectedPage, setSelectedPage] = useState(null);
  const [viewMode, setViewMode] = useState('side-by-side');
  const [dragOver, setDragOver] = useState({ original: false, revised: false });

  const handleDrop = useCallback((e, type) => {
    e.preventDefault();
    setDragOver(prev => ({ ...prev, [type]: false }));
    
    const file = e.dataTransfer.files[0];
    if (file && file.type === 'application/pdf') {
      if (type === 'original') {
        setOriginalFile(file);
      } else {
        setRevisedFile(file);
      }
    }
  }, []);

  const handleDragOver = useCallback((e, type) => {
    e.preventDefault();
    setDragOver(prev => ({ ...prev, [type]: true }));
  }, []);

  const handleDragLeave = useCallback((e, type) => {
    e.preventDefault();
    setDragOver(prev => ({ ...prev, [type]: false }));
  }, []);

  const handleFileSelect = (e, type) => {
    const file = e.target.files[0];
    if (file) {
      if (type === 'original') {
        setOriginalFile(file);
      } else {
        setRevisedFile(file);
      }
    }
  };

  const handleCompare = async () => {
    if (!originalFile || !revisedFile) return;
    
    setLoading(true);
    setError(null);
    setResults(null);
    setSelectedPage(null);
    setProgress({ current: 0, total: 0, status: 'Loading PDFs...' });
    
    const startTime = Date.now();
    
    try {
      const data = await comparePdfs(
        originalFile, 
        revisedFile, 
        setProgress,
        { scale: 1.5, threshold: 0.1 }
      );
      
      data.metadata.processingTimeMs = Date.now() - startTime;
      setResults(data);
      
      // Auto-select first modified page
      const firstModified = data.pages.find(p => p.status === 'modified');
      if (firstModified) {
        setSelectedPage(firstModified);
      }
    } catch (err) {
      console.error('Comparison failed:', err);
      setError(err.message || 'Failed to compare PDFs');
    }
    
    setLoading(false);
    setProgress(null);
  };

  const handleReset = () => {
    setOriginalFile(null);
    setRevisedFile(null);
    setResults(null);
    setSelectedPage(null);
    setError(null);
    setProgress(null);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'identical': return 'var(--status-identical)';
      case 'modified': return 'var(--status-modified)';
      case 'added': return 'var(--status-added)';
      case 'removed': return 'var(--status-removed)';
      default: return 'var(--text-secondary)';
    }
  };

  const getStatusBg = (status) => {
    switch (status) {
      case 'identical': return 'var(--status-identical-bg)';
      case 'modified': return 'var(--status-modified-bg)';
      case 'added': return 'var(--status-added-bg)';
      case 'removed': return 'var(--status-removed-bg)';
      default: return 'var(--surface-secondary)';
    }
  };

  return (
    <div className="app">
      {/* Header */}
      <header className="header">
        <div className="header-content">
          <div className="logo">
            <div className="logo-icon">
              <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
                <rect x="2" y="4" width="18" height="24" rx="2" stroke="currentColor" strokeWidth="2"/>
                <rect x="12" y="4" width="18" height="24" rx="2" fill="var(--accent)" stroke="var(--accent)" strokeWidth="2"/>
                <path d="M17 12h8M17 16h8M17 20h6" stroke="var(--bg-primary)" strokeWidth="2" strokeLinecap="round"/>
              </svg>
            </div>
            <div>
              <h1>PDF Comparator</h1>
              <span className="tagline">Document Revision Comparison</span>
            </div>
          </div>
          {results && (
            <button className="btn btn-secondary" onClick={handleReset}>
              New Comparison
            </button>
          )}
        </div>
      </header>

      <main className="main">
        {!results ? (
          /* Upload Section */
          <div className="upload-section">
            <div className="upload-grid">
              {/* Original File */}
              <div
                className={`upload-zone ${dragOver.original ? 'drag-over' : ''} ${originalFile ? 'has-file' : ''}`}
                onDrop={(e) => handleDrop(e, 'original')}
                onDragOver={(e) => handleDragOver(e, 'original')}
                onDragLeave={(e) => handleDragLeave(e, 'original')}
              >
                <input
                  type="file"
                  accept=".pdf"
                  onChange={(e) => handleFileSelect(e, 'original')}
                  id="original-input"
                  className="file-input"
                />
                <label htmlFor="original-input" className="upload-label">
                  {originalFile ? (
                    <div className="file-selected">
                      <div className="file-icon-wrapper success">
                        <CheckIcon />
                      </div>
                      <span className="file-name">{originalFile.name}</span>
                      <span className="file-size">{(originalFile.size / 1024 / 1024).toFixed(2)} MB</span>
                    </div>
                  ) : (
                    <>
                      <UploadIcon />
                      <span className="upload-title">Original Document</span>
                      <span className="upload-hint">Drop PDF here or click to browse</span>
                    </>
                  )}
                </label>
                <div className="upload-badge">ORIGINAL</div>
              </div>

              {/* VS Divider */}
              <div className="vs-divider">
                <span>VS</span>
              </div>

              {/* Revised File */}
              <div
                className={`upload-zone ${dragOver.revised ? 'drag-over' : ''} ${revisedFile ? 'has-file' : ''}`}
                onDrop={(e) => handleDrop(e, 'revised')}
                onDragOver={(e) => handleDragOver(e, 'revised')}
                onDragLeave={(e) => handleDragLeave(e, 'revised')}
              >
                <input
                  type="file"
                  accept=".pdf"
                  onChange={(e) => handleFileSelect(e, 'revised')}
                  id="revised-input"
                  className="file-input"
                />
                <label htmlFor="revised-input" className="upload-label">
                  {revisedFile ? (
                    <div className="file-selected">
                      <div className="file-icon-wrapper success">
                        <CheckIcon />
                      </div>
                      <span className="file-name">{revisedFile.name}</span>
                      <span className="file-size">{(revisedFile.size / 1024 / 1024).toFixed(2)} MB</span>
                    </div>
                  ) : (
                    <>
                      <UploadIcon />
                      <span className="upload-title">Revised Document</span>
                      <span className="upload-hint">Drop PDF here or click to browse</span>
                    </>
                  )}
                </label>
                <div className="upload-badge accent">REVISED</div>
              </div>
            </div>

            {error && (
              <div className="error-message">
                <span>⚠️ {error}</span>
              </div>
            )}

            {progress && (
              <div className="progress-container">
                <div className="progress-bar">
                  <div 
                    className="progress-fill" 
                    style={{ width: `${progress.total > 0 ? (progress.current / progress.total) * 100 : 0}%` }}
                  />
                </div>
                <span className="progress-text">{progress.status}</span>
              </div>
            )}

            <button
              className="btn btn-primary btn-large"
              onClick={handleCompare}
              disabled={!originalFile || !revisedFile || loading}
            >
              {loading ? (
                <>
                  <SpinnerIcon />
                  Comparing Documents...
                </>
              ) : (
                'Compare Documents'
              )}
            </button>
          </div>
        ) : (
          /* Results Section */
          <div className="results-section">
            {/* Summary Cards */}
            <div className="summary-grid">
              <div className="summary-card">
                <div className="summary-value" style={{ color: 'var(--status-identical)' }}>
                  {results.summary.identical}
                </div>
                <div className="summary-label">Identical</div>
              </div>
              <div className="summary-card">
                <div className="summary-value" style={{ color: 'var(--status-modified)' }}>
                  {results.summary.modified}
                </div>
                <div className="summary-label">Modified</div>
              </div>
              <div className="summary-card">
                <div className="summary-value" style={{ color: 'var(--status-added)' }}>
                  {results.summary.added}
                </div>
                <div className="summary-label">Added</div>
              </div>
              <div className="summary-card">
                <div className="summary-value" style={{ color: 'var(--status-removed)' }}>
                  {results.summary.removed}
                </div>
                <div className="summary-label">Removed</div>
              </div>
            </div>

            {/* Metadata */}
            <div className="metadata">
              <span>Original: {results.originalPages} pages</span>
              <span className="separator">•</span>
              <span>Revised: {results.revisedPages} pages</span>
              <span className="separator">•</span>
              <span>Processed in {(results.metadata.processingTimeMs / 1000).toFixed(1)}s</span>
            </div>

            {/* Page Navigator */}
            <div className="page-navigator">
              <div className="page-nav-header">
                <h3>Page Overview</h3>
                <div className="legend">
                  <span className="legend-item"><span className="dot identical"></span> Identical</span>
                  <span className="legend-item"><span className="dot modified"></span> Modified</span>
                  <span className="legend-item"><span className="dot added"></span> Added</span>
                  <span className="legend-item"><span className="dot removed"></span> Removed</span>
                </div>
              </div>
              <div className="page-grid">
                {results.pages.map((page) => (
                  <button
                    key={page.pageNumber}
                    className={`page-thumb ${page.status} ${selectedPage?.pageNumber === page.pageNumber ? 'selected' : ''}`}
                    onClick={() => setSelectedPage(page)}
                    style={{
                      '--status-color': getStatusColor(page.status),
                      '--status-bg': getStatusBg(page.status)
                    }}
                  >
                    <span className="page-number">{page.pageNumber}</span>
                    {page.status === 'modified' && (
                      <span className="diff-badge">{page.diffPercentage}%</span>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Visual Comparison */}
            {selectedPage && (
              <div className="visual-comparison">
                <div className="comparison-header">
                  <h3>
                    Page {selectedPage.pageNumber}
                    <span 
                      className="status-badge"
                      style={{ 
                        background: getStatusBg(selectedPage.status),
                        color: getStatusColor(selectedPage.status)
                      }}
                    >
                      {selectedPage.status}
                    </span>
                  </h3>
                  
                  {selectedPage.status === 'modified' && (
                    <div className="view-toggle">
                      <button 
                        className={viewMode === 'side-by-side' ? 'active' : ''}
                        onClick={() => setViewMode('side-by-side')}
                      >
                        Side by Side
                      </button>
                      <button 
                        className={viewMode === 'slider' ? 'active' : ''}
                        onClick={() => setViewMode('slider')}
                      >
                        Slider
                      </button>
                      <button 
                        className={viewMode === 'toggle' ? 'active' : ''}
                        onClick={() => setViewMode('toggle')}
                      >
                        Toggle
                      </button>
                      <button 
                        className={viewMode === 'overlay' ? 'active' : ''}
                        onClick={() => setViewMode('overlay')}
                      >
                        Overlay
                      </button>
                    </div>
                  )}
                </div>

                {selectedPage.status === 'modified' && (
                  <>
                    {viewMode === 'side-by-side' && (
                      <div className="image-grid two-col">
                        <div className="image-panel">
                          <h4>Original</h4>
                          <img src={selectedPage.originalImage} alt="Original page" />
                        </div>
                        <div className="image-panel">
                          <h4>Revised</h4>
                          <img src={selectedPage.revisedImage} alt="Revised page" />
                        </div>
                      </div>
                    )}
                    
                    {viewMode === 'slider' && (
                      <SliderCompare 
                        originalImage={selectedPage.originalImage}
                        revisedImage={selectedPage.revisedImage}
                      />
                    )}
                    
                    {viewMode === 'toggle' && (
                      <ToggleCompare
                        originalImage={selectedPage.originalImage}
                        revisedImage={selectedPage.revisedImage}
                      />
                    )}
                    
                    {viewMode === 'overlay' && (
                      <div className="image-grid single">
                        <div className="image-panel">
                          <h4>Overlay (50% blend of both documents)</h4>
                          <img src={selectedPage.overlayImage} alt="Overlay comparison" />
                          <span className="change-indicator">Differences appear as ghosting/blur</span>
                        </div>
                      </div>
                    )}
                  </>
                )}

                {selectedPage.status === 'added' && (
                  <div className="image-grid single">
                    <div className="image-panel added">
                      <h4>New Page (Added in Revision)</h4>
                      <img src={selectedPage.revisedImage} alt="Added page" />
                    </div>
                  </div>
                )}

                {selectedPage.status === 'removed' && (
                  <div className="image-grid single">
                    <div className="image-panel removed">
                      <h4>Removed Page (Not in Revision)</h4>
                      <img src={selectedPage.originalImage} alt="Removed page" />
                    </div>
                  </div>
                )}

                {selectedPage.status === 'identical' && (
                  <div className="identical-message">
                    <CheckIcon />
                    <span>This page is identical in both documents</span>
                  </div>
                )}
                
                {/* Comprehensive Change Summary */}
                {selectedPage.changeAnalysis && (
                  <ChangeSummary analysis={selectedPage.changeAnalysis} status={selectedPage.status} />
                )}
              </div>
            )}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="footer">
        <span>PDF Comparator • Built for document revision comparison</span>
      </footer>
    </div>
  );
}

export default App;
