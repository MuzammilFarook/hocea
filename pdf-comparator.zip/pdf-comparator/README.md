# PDF Comparator

A visual document revision comparison tool that compares two PDF documents page-by-page and highlights the differences. **Runs entirely in the browser** — no server or native dependencies required.

## Features

- **Visual Comparison**: Renders each page and performs pixel-level comparison
- **Diff Highlighting**: Red overlay shows exactly what changed between versions
- **Page Overview**: Thumbnail grid shows status of all pages at a glance
- **Multiple View Modes**: Side-by-side, overlay, or diff-only views
- **Support for Large PDFs**: Handles 20-30+ page documents
- **Drag & Drop**: Easy file upload with drag and drop support
- **No Server Required**: Everything runs in the browser

## Tech Stack

- **Frontend**: React + Vite
- **PDF Rendering**: pdf.js (browser-based)
- **Image Comparison**: pixelmatch

## Prerequisites

- Node.js 18+ (any recent version works)
- npm or yarn

**No native dependencies required!** This version works on Windows, Mac, and Linux without any additional setup.

## Installation

```bash
# Navigate to the project folder
cd pdf-comparator

# Install dependencies
npm install
```

## Running the Application

```bash
npm run dev
```

Then open your browser to: **http://localhost:3000**

That's it! No server to start, no native modules to build.

## Usage

1. **Upload Documents**: Drag and drop or click to upload the original PDF and revised PDF
2. **Compare**: Click "Compare Documents" to start the comparison
3. **Review Results**: 
   - Summary cards show count of identical, modified, added, and removed pages
   - Click on any page thumbnail to see detailed comparison
   - Use view mode toggle to switch between side-by-side, overlay, and diff views

## Project Structure

```
pdf-comparator/
├── package.json
├── vite.config.js
├── index.html
└── src/
    ├── main.jsx        # React entry point
    ├── App.jsx         # Main React component with comparison logic
    └── index.css       # Styles
```

## How It Works

1. PDFs are loaded using pdf.js directly in the browser
2. Each page is rendered to an HTML Canvas element
3. Pixel-by-pixel comparison is performed using the pixelmatch library
4. Results are displayed with visual diff overlays

## Performance Tips

For large documents (20-30+ pages):

- Comparison happens page-by-page with progress indication
- Each page takes ~0.5-1 second depending on complexity
- Total time for 30 pages: approximately 15-30 seconds

## Build for Production

```bash
npm run build
```

The built files will be in the `dist/` folder. You can deploy these to any static hosting (Netlify, Vercel, GitHub Pages, etc.).

## Troubleshooting

### "PDF failed to load"
Make sure the file is a valid PDF. Some password-protected or corrupted PDFs may not load.

### Comparison is slow
This is expected for large documents. The progress bar shows current status.

### Browser runs out of memory
For very large PDFs (50+ pages), try closing other tabs to free up memory.

## License

MIT
