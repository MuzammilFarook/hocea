import express        from 'express'
import { createServer } from 'http'
import { Server }       from 'socket.io'
import { join, dirname } from 'path'
import { fileURLToPath } from 'url'
import cors             from 'cors'
import routes           from './routes.js'

const __dir = dirname(fileURLToPath(import.meta.url))
const app    = express()
const server = createServer(app)
const io     = new Server(server, { cors: { origin: '*' } })

app.set('io', io)

app.use(cors())
app.use(express.json())

// Serve the frontend
app.use(express.static(join(__dir, '..', 'public')))

// API routes
app.use('/api', routes)

// Health check
app.get('/health', (_, res) => res.json({ ok: true, service: 'CampusHub' }))

// Fallback → index.html (SPA)
app.get('*', (_, res) => res.sendFile(join(__dir, '..', 'public', 'index.html')))

io.on('connection', socket => {
  console.log('Socket connected:', socket.id)
  socket.on('disconnect', () => console.log('Socket disconnected:', socket.id))
})

const PORT = process.env.PORT || 3000
server.listen(PORT, () => {
  console.log(`\n🎓 CampusHub running → http://localhost:${PORT}`)
  console.log(`   Demo: student@campus.edu / student123`)
  console.log(`   Admin: admin@campus.edu  / admin123\n`)
})
