import { join, dirname } from 'path'
import { fileURLToPath }  from 'url'
import { Low }            from 'lowdb'
import { JSONFile }       from 'lowdb/node'
import bcrypt             from 'bcryptjs'

const __dir = dirname(fileURLToPath(import.meta.url))
const file  = join(__dir, '..', 'db.json')

const adapter = new JSONFile(file)
const db      = new Low(adapter, {})

export async function getDB() {
  await db.read()

  // Seed default data on first run
  if (!db.data.users) {
    db.data = {
      users: [
        {
          id: 'u1', name: 'Arjun Mehta', email: 'student@campus.edu',
          password: await bcrypt.hash('student123', 10),
          role: 'student', dept: 'Computer Science', year: 3, sem: 5,
          cgpa: 8.6, credits: 96,
          courses: [
            { code:'CS301', name:'Data Structures',   credits:4, att:80 },
            { code:'CS302', name:'DBMS',              credits:4, att:65 },
            { code:'CS303', name:'Operating Systems', credits:4, att:90 },
            { code:'CS304', name:'Computer Networks', credits:3, att:72 },
            { code:'CS305', name:'Machine Learning',  credits:3, att:55 },
          ]
        },
        {
          id: 'u2', name: 'Admin User', email: 'admin@campus.edu',
          password: await bcrypt.hash('admin123', 10),
          role: 'admin', dept: 'Administration',
          year: 1, sem: 1, cgpa: 0, credits: 0, courses: []
        }
      ],
      events: [
        { id:'e1', title:'TechSymposium 2025 — Hackathon', desc:'Annual inter-college hackathon. Build solutions for real-world problems in 24 hours. Prizes worth ₹1,50,000.', cat:'Academic',  venue:'CSE Block · Seminar Hall', date:'2025-10-15', time:'9:00 AM',  organizer:'CSE Department', capacity:200, rsvps:[] },
        { id:'e2', title:'Guest Lecture: AI in Fintech',   desc:'Industry expert discusses AI applications in modern banking and financial services.',                           cat:'Workshop',  venue:'Seminar Hall A',           date:'2025-10-18', time:'2:00 PM',  organizer:'T&P Cell',       capacity:150, rsvps:[] },
        { id:'e3', title:'Cultural Night — Diwali Fest',   desc:'Celebrate Diwali with live performances, food stalls, rangoli competition and grand lighting ceremony.',        cat:'Cultural',  venue:'Open Air Auditorium',       date:'2025-10-22', time:'6:00 PM',  organizer:'Student Council',capacity:500, rsvps:[] },
        { id:'e4', title:'Placement Prep Workshop',        desc:'Resume building, aptitude drills, and mock interview sessions. Open to 3rd and 4th year students.',             cat:'Placement', venue:'LT-3',                      date:'2025-10-28', time:'10:00 AM', organizer:'T&P Cell',       capacity:100, rsvps:[] },
        { id:'e5', title:'Sports Day 2025',                desc:'Inter-department cricket, football, badminton and athletics. Register your team before Oct 12.',                cat:'Sports',    venue:'Campus Ground',             date:'2025-11-02', time:'7:00 AM',  organizer:'Sports Committee',capacity:300, rsvps:[] },
      ],
      facilities: [
        { id:'f1', name:'CS Lab — Block A', type:'lab',       icon:'💻', iconBg:'#EAF3DE', loc:'CSE Block, GF',  total:40,  occ:8,   status:'available', open:'08:00', close:'20:00', slot:60,  bookings:[] },
        { id:'f2', name:'Central Library',  type:'library',   icon:'📚', iconBg:'#FFF3CD', loc:'Main Building',  total:60,  occ:42,  status:'busy',      open:'08:00', close:'21:00', slot:120, bookings:[] },
        { id:'f3', name:'Sports Complex',   type:'sports',    icon:'🏀', iconBg:'#D6EAF8', loc:'Campus North',   total:50,  occ:10,  status:'available', open:'06:00', close:'20:00', slot:60,  bookings:[] },
        { id:'f4', name:'Cafeteria',        type:'cafeteria', icon:'🍱', iconBg:'#FFE4E8', loc:'Central Campus', total:200, occ:180, status:'busy',      open:'07:30', close:'21:00', slot:30,  bookings:[] },
        { id:'f5', name:'Seminar Hall A',   type:'seminar',   icon:'🎤', iconBg:'#EDE7F6', loc:'Admin Block',    total:150, occ:150, status:'busy',      open:'09:00', close:'18:00', slot:120, bookings:[] },
        { id:'f6', name:'Health Center',    type:'health',    icon:'🏥', iconBg:'#FFECD2', loc:'Hostel Block',   total:10,  occ:0,   status:'available', open:'08:00', close:'20:00', slot:30,  bookings:[] },
      ],
      notices: [
        { id:'n1', title:'Exam Schedule Released',       body:'November 2025 end-semester exam schedule has been published. Download the timetable from the examination portal.',         priority:'high',   dept:'all', postedBy:'Exam Cell',  date:'2025-10-01' },
        { id:'n2', title:'Semester 5 Hostel Fee Due',    body:'Hostel fees for Semester 5 are due by October 20. A late fee of ₹500 per week will be levied after the deadline.',         priority:'high',   dept:'all', postedBy:'Accounts',   date:'2025-10-02' },
        { id:'n3', title:'TechSymposium Registration',   body:'Register for the annual hackathon before October 15. Teams of 2–4 students. Prizes include internship offers.',            priority:'medium', dept:'CSE', postedBy:'CSE Dept',   date:'2025-10-03' },
        { id:'n4', title:'New ACM Journals Available',   body:'ACM Digital Library access has been enabled. Log in using your campus email ID at acm.org/digital-library.',               priority:'low',    dept:'CSE', postedBy:'Library',    date:'2025-10-04' },
        { id:'n5', title:'Anti-Ragging Workshop',        body:'Mandatory awareness session on October 19 at 11 AM in the Main Auditorium. All first-year students must attend.',          priority:'high',   dept:'all', postedBy:'Dean Office', date:'2025-10-05' },
        { id:'n6', title:'Internship Applications Open', body:'Applications for summer 2026 internships are now open. Eligible: 3rd year students with CGPA ≥ 7.0.',                      priority:'medium', dept:'all', postedBy:'T&P Cell',   date:'2025-10-06' },
      ]
    }
    await db.write()
    console.log('✓ db.json seeded with default data')
  }

  return db
}
