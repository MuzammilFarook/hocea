import { Router }  from 'express'
import bcrypt       from 'bcryptjs'
import { getDB }    from './db.js'
import { signToken, protect, adminOnly } from './auth.js'

const r = Router()

// ─── helpers ───────────────────────────────
function slots(open, close, dur) {
  const list = []
  let [h, m] = open.split(':').map(Number)
  const [ch, cm] = close.split(':').map(Number)
  while (h * 60 + m + dur <= ch * 60 + cm) {
    const from = `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`
    let nh = h, nm = m + dur
    if (nm >= 60) { nh += Math.floor(nm / 60); nm %= 60 }
    const to = `${String(nh).padStart(2,'0')}:${String(nm).padStart(2,'0')}`
    list.push(`${from}–${to}`)
    h = nh; m = nm
  }
  return list
}

// ═══════════════════════════════════════════
//  AUTH
// ═══════════════════════════════════════════

// POST /api/auth/login
r.post('/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body
    const db   = await getDB()
    const user = db.data.users.find(u => u.email === email.toLowerCase())
    if (!user || !(await bcrypt.compare(password, user.password)))
      return res.status(401).json({ message: 'Invalid credentials' })

    const { password: _, ...safe } = user
    const token = signToken({ id: user.id, role: user.role })
    res.json({ token, user: safe })
  } catch (e) { res.status(500).json({ message: e.message }) }
})

// GET /api/auth/me
r.get('/auth/me', protect, async (req, res) => {
  const db   = await getDB()
  const user = db.data.users.find(u => u.id === req.user.id)
  if (!user) return res.status(404).json({ message: 'User not found' })
  const { password: _, ...safe } = user
  res.json(safe)
})

// ═══════════════════════════════════════════
//  EVENTS
// ═══════════════════════════════════════════

// GET /api/events
r.get('/events', protect, async (req, res) => {
  const db = await getDB()
  res.json(db.data.events)
})

// POST /api/events  (admin)
r.post('/events', protect, adminOnly, async (req, res) => {
  const db = await getDB()
  const ev = { ...req.body, id: `e${Date.now()}`, rsvps: [] }
  db.data.events.push(ev)
  await db.write()
  res.status(201).json(ev)
})

// POST /api/events/:id/rsvp
r.post('/events/:id/rsvp', protect, async (req, res) => {
  const db = await getDB()
  const ev = db.data.events.find(e => e.id === req.params.id)
  if (!ev) return res.status(404).json({ message: 'Event not found' })
  if (ev.rsvps.includes(req.user.id))
    return res.status(400).json({ message: 'Already registered' })
  if (ev.capacity && ev.rsvps.length >= ev.capacity)
    return res.status(400).json({ message: 'Event is full' })
  ev.rsvps.push(req.user.id)
  await db.write()

  req.app.get('io').emit('event:updated', { id: ev.id, rsvpCount: ev.rsvps.length })
  res.json({ rsvpCount: ev.rsvps.length })
})

// DELETE /api/events/:id/rsvp
r.delete('/events/:id/rsvp', protect, async (req, res) => {
  const db = await getDB()
  const ev = db.data.events.find(e => e.id === req.params.id)
  if (!ev) return res.status(404).json({ message: 'Event not found' })
  ev.rsvps = ev.rsvps.filter(id => id !== req.user.id)
  await db.write()

  req.app.get('io').emit('event:updated', { id: ev.id, rsvpCount: ev.rsvps.length })
  res.json({ rsvpCount: ev.rsvps.length })
})

// ═══════════════════════════════════════════
//  FACILITIES
// ═══════════════════════════════════════════

// GET /api/facilities
r.get('/facilities', protect, async (req, res) => {
  const db = await getDB()
  // Strip booking detail — send summary only
  res.json(db.data.facilities.map(({ bookings, ...f }) => ({
    ...f,
    bookingCount: bookings.length
  })))
})

// GET /api/facilities/:id/slots?date=YYYY-MM-DD
r.get('/facilities/:id/slots', protect, async (req, res) => {
  const db  = await getDB()
  const fac = db.data.facilities.find(f => f.id === req.params.id)
  if (!fac) return res.status(404).json({ message: 'Facility not found' })

  const date = req.query.date || new Date().toISOString().split('T')[0]
  const all  = slots(fac.open, fac.close, fac.slot)
  const booked = fac.bookings.filter(b => b.date === date).map(b => b.slot)

  res.json(all.map(s => ({
    slot:       s,
    available:  !booked.includes(s),
    bookedByMe: fac.bookings.some(b => b.date === date && b.slot === s && b.userId === req.user.id)
  })))
})

// POST /api/facilities/:id/book
r.post('/facilities/:id/book', protect, async (req, res) => {
  const { date, slot } = req.body
  const db  = await getDB()
  const fac = db.data.facilities.find(f => f.id === req.params.id)
  if (!fac) return res.status(404).json({ message: 'Facility not found' })

  const conflict = fac.bookings.find(b => b.date === date && b.slot === slot)
  if (conflict) return res.status(400).json({ message: 'Slot already booked' })

  fac.bookings.push({ userId: req.user.id, date, slot, bookedAt: new Date().toISOString() })
  fac.occ = Math.min(fac.occ + 1, fac.total)
  if (fac.occ / fac.total >= 0.7) fac.status = 'busy'

  await db.write()

  req.app.get('io').emit('facility:updated', {
    id: fac.id, occ: fac.occ, total: fac.total, status: fac.status
  })
  res.json({ message: 'Slot booked', slot, date })
})

// DELETE /api/facilities/:id/book
r.delete('/facilities/:id/book', protect, async (req, res) => {
  const { date, slot } = req.body
  const db  = await getDB()
  const fac = db.data.facilities.find(f => f.id === req.params.id)
  if (!fac) return res.status(404).json({ message: 'Facility not found' })

  const before = fac.bookings.length
  fac.bookings = fac.bookings.filter(b => !(b.date === date && b.slot === slot && b.userId === req.user.id))
  if (fac.bookings.length < before) {
    fac.occ = Math.max(fac.occ - 1, 0)
    if (fac.occ / fac.total < 0.7) fac.status = 'available'
    await db.write()
    req.app.get('io').emit('facility:updated', {
      id: fac.id, occ: fac.occ, total: fac.total, status: fac.status
    })
  }
  res.json({ message: 'Booking cancelled', slot, date })
})

// ═══════════════════════════════════════════
//  NOTICES
// ═══════════════════════════════════════════

// GET /api/notices
r.get('/notices', protect, async (req, res) => {
  const db = await getDB()
  res.json(db.data.notices)
})

// POST /api/notices  (admin)
r.post('/notices', protect, adminOnly, async (req, res) => {
  const db = await getDB()
  const n  = { ...req.body, id: `n${Date.now()}`, date: new Date().toISOString().split('T')[0] }
  db.data.notices.unshift(n)
  await db.write()
  req.app.get('io').emit('notice:new', n)
  res.status(201).json(n)
})

// DELETE /api/notices/:id  (admin)
r.delete('/notices/:id', protect, adminOnly, async (req, res) => {
  const db = await getDB()
  db.data.notices = db.data.notices.filter(n => n.id !== req.params.id)
  await db.write()
  res.json({ message: 'Notice deleted' })
})

export default r
