# CampusHub — Full Stack (No DB Setup)

HTML + Bootstrap + jQuery frontend · Node.js + Express backend · `db.json` file storage (lowdb)

## Stack

| Layer    | Tech                                      |
|----------|-------------------------------------------|
| Frontend | HTML5, Bootstrap 5, jQuery, Bootstrap Icons |
| Backend  | Node.js (ESM), Express                    |
| Storage  | lowdb — plain `db.json` file, zero setup  |
| Auth     | JWT + bcryptjs                            |
| Realtime | Socket.io                                 |

## Run in 2 steps

```bash
npm install
npm run dev        # → http://localhost:3000
```

`db.json` is created automatically on first run with seeded demo data.

## Demo credentials

| Role    | Email                 | Password    |
|---------|-----------------------|-------------|
| Student | student@campus.edu    | student123  |
| Admin   | admin@campus.edu      | admin123    |

## Project layout

```
campushub-fullstack/
├── package.json
├── db.json              ← auto-created, all data lives here
├── public/
│   └── index.html       ← entire frontend (one file)
└── server/
    ├── index.js         ← Express + Socket.io entry
    ├── db.js            ← lowdb helper + seed data
    ├── auth.js          ← JWT sign/verify middleware
    └── routes.js        ← all API routes
```

## API endpoints

```
POST   /api/auth/login
GET    /api/auth/me

GET    /api/events
POST   /api/events/:id/rsvp
DELETE /api/events/:id/rsvp

GET    /api/facilities
GET    /api/facilities/:id/slots?date=YYYY-MM-DD
POST   /api/facilities/:id/book
DELETE /api/facilities/:id/book

GET    /api/notices
POST   /api/notices          (admin)
DELETE /api/notices/:id      (admin)
```

## Socket.io events

| Event              | Payload                              |
|--------------------|--------------------------------------|
| `event:updated`    | `{ id, rsvpCount }`                  |
| `facility:updated` | `{ id, occ, total, status }`         |
| `notice:new`       | full notice object                   |
